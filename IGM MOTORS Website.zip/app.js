// const flash = require("connect-flash");
const express = require("express");
const path = require("path");
var hbs = require("hbs");
const crypto = require("crypto");
const mongoose = require("mongoose");
const passport = require("passport");
const flash = require("express-flash");
const session = require("express-session");

const AuthRouter = require("./routes/auth");
const VehicleRouter = require("./routes/Vehicle");
const buyerDashboardRouter = require("./routes/BuyerDashboardRouter");
const emailsRouter = require("./routes/mailsRouter");

const User = require("./models/UserModel");
const Image = require("./models/ImagesModel");
const Vehicle = require("./models/VehicleModel");

const app = express();
const port = 3000 || process.env.PORT;
// Generate a random 32-byte (256-bit) secret key
const secretKey = crypto.randomBytes(32).toString("hex");
const staticPath = path.join(__dirname, "static");
const partialPath = path.join(__dirname, "./views/partials");
const templatePath = path.join(__dirname, "./views");

const db_URL =
  "mongodb://contactimtanan:cfd%402878@ac-t4vk7kn-shard-00-00.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-01.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-02.omvaq7k.mongodb.net:27017/IGMMotors?ssl=true&replicaSet=atlas-fojkho-shard-0&authSource=admin&retryWrites=true&w=majority";

const initializePassport = require("./controllers/passport-config");
initializePassport(
  passport,
  async (email) => await User.findOne({ email: email }),
  async (id) => {
    const user = await User.findOne({ _id: id });
    return user;
  }
);

hbs.registerPartials(partialPath);
// Define the custom equality helper
hbs.registerHelper("if_eq", function (a, b, opts) {
  if (a === b) {
    return opts.fn(this);
  } else {
    return opts.inverse(this);
  }
});
// Setting templete engine.
app.set("views", templatePath);
app.set("view engine", "hbs");

// Connecting DB(MongoDB)
const db = async () => {
  try {
    const conn = await mongoose.connect(db_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log("MongoDB connected");
  } catch (err) {
    console.log("MongoDB Error : Failed to connect");
    console.log(err);
    process.exit(1);
  }
};

db();

// Set static folder path to use static files like JS,CSS,images
app.use("/static", express.static(staticPath));
// Parse URL-encoded data
app.use(express.urlencoded({ extended: false }));
app.use(flash()); // use connect-flash for flash messages stored in session

app.use(
  session({
    secret: secretKey,
    saveUninitialized: false,
    resave: false,
    cookie: { maxAge: 60 * 60 * 1000 * 1000 }, // 1 hour
  })
);

app.use(passport.initialize());
app.use(passport.session());
app.use("/Vehicles_Dashboard", VehicleRouter);
app.use("/Buyer-Dashboard", buyerDashboardRouter);
app.use("/emails", emailsRouter);
// Authentication(Login/Register) a user
app.use("/auth", AuthRouter);

// Find electric cars and their images
async function findElectricCarsAndImages() {
  try {
    const electricCars = await Vehicle.find({ type: "car", isElectric: true });

    if (electricCars.length > 0) {
      const electricCarIds = electricCars.map((car) => car._id);
      const electricCarImages = await Image.find({
        vehicle: { $in: electricCarIds },
      });
      return electricCarImages;
    } else {
      // If there are no electric cars, find vehicles with the most images
      const mostImagesVehicles = await Vehicle.aggregate([
        {
          $group: {
            _id: "$type",
            maxImages: { $max: { $size: "$images" } },
          },
        },
        {
          $lookup: {
            from: "vehicles",
            localField: "_id",
            foreignField: "type",
            as: "vehicles",
          },
        },
        {
          $unwind: "$vehicles",
        },
        {
          $match: {
            $expr: { $eq: [{ $size: "$vehicles.images" }, "$maxImages"] },
          },
        },
      ]);

      const mostImagesVehicleIds = mostImagesVehicles.map(
        (vehicle) => vehicle.vehicles._id
      );
      const mostImages = await Image.find({
        vehicle: { $in: mostImagesVehicleIds },
      });

      return mostImages;
    }
  } catch (error) {
    console.error(error);
    throw error;
  }
}

app.get("/", async (req, res) => {
  if (req.isAuthenticated()) {
    flag = true;
  } else {
    flag = false;
  }
  const finalImages = await findElectricCarsAndImages();

  const imageMap = [];
  finalImages.forEach((image) => {
    const base64Data = image.imageData.data.toString("base64");
    imageMap.push({
      contentType: image.imageData.contentType,
      data: base64Data,
    });
  });

  // Get the first five or fewer items from imageMap
  const numberOfImagesToShow = 5;
  const imagesToRender = imageMap.slice(0, numberOfImagesToShow);

  res.render("home", { loginCheck: flag, images: imagesToRender });
});

// Route handler
app.get("/profile", (req, res) => {
  console.log("Logged in user:", req.session.passport);
  if (req.isAuthenticated()) {
    // User is logged in
    console.log("Logged in user:", req.session.passport.user);
  } else {
    console.log("No user");
  }
});

app.get("*", (req, res) => {
  res.status(404);
  res.render("404Page");
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`, app.settings.env);
});
