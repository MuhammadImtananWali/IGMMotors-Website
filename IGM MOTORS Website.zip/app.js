// const flash = require("connect-flash");
const express = require("express");
const path = require("path");
var hbs = require("hbs");
const crypto = require('crypto');
const mongoose = require("mongoose");
const passport = require("passport");
const flash = require('express-flash');
const bodyParser = require('body-parser');
const session = require('express-session');

const AuthRouter = require("./routes/auth");
const VehicleRouter = require("./routes/Vehicle");
const mailsRouter = require("./routes/mailsRouter");
const buyerDashboardRouter = require("./routes/BuyerDashboardRouter");

const User = require("./models/UserModel");

const app = express();
const port = 3000 || process.env.PORT;
// Generate a random 32-byte (256-bit) secret key
const secretKey = crypto.randomBytes(32).toString('hex');
const staticPath = path.join(__dirname, "static");
const partialPath = path.join(__dirname, "./views/partials");
const templatePath = path.join(__dirname, "./views");

const db_URL = 'mongodb://contactimtanan:cfd%402878@ac-t4vk7kn-shard-00-00.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-01.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-02.omvaq7k.mongodb.net:27017/IGMMotors?ssl=true&replicaSet=atlas-fojkho-shard-0&authSource=admin&retryWrites=true&w=majority';

const initializePassport = require("./controllers/passport-config");
initializePassport(
  passport,
  async (email) => await User.findOne({ email: email }),
  async (id) => {
    const user = await User.findOne({ _id: id });
    return user;
  }
);

hbs.registerPartials(partialPath);
// Setting templete engine.
app.set('views', templatePath);
app.set("view engine", "hbs");

// Connecting DB(MongoDB)
const db = async () => {
  try {
    const conn = await mongoose.connect(db_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    console.log("MongoDB connected");
  } catch (err) {
    console.log("MongoDB Error : Failed to connect");
    console.log(err);
    process.exit(1);
  }
};

db();

// Set static folder path to use static files like JS,CSS,images
app.use("/static", express.static(staticPath));
// Parse URL-encoded data
app.use(express.urlencoded({ extended: false }));
app.use(flash()); // use connect-flash for flash messages stored in session

app.use(
  session({
    secret: secretKey,
    saveUninitialized: false,
    resave: false,
    cookie: { maxAge: 60 * 60 * 1000 * 1000 }, // 1 hour
  })
);

app.use(passport.initialize());
app.use(passport.session());
app.use('/Vehicles_Dashboard', VehicleRouter);
app.use('/Buyer-Dashboard', buyerDashboardRouter);
app.use("/queries",mailsRouter);
// Authentication(Login/Register) a user
app.use("/auth", AuthRouter);

app.get("/", (req, res) => {
  if (req.isAuthenticated()) {
    flag = true;
  }
  else{
    flag = false;
  }
  res.render("home",{loginCheck: flag});
});

// Route handler
app.get("/profile", (req, res) => {
  console.log("Logged in user:", req.session.passport);
  if (req.isAuthenticated()) {
    // User is logged in
    console.log("Logged in user:", req.session.passport.user);
  } else {
    console.log("No user");
  }
});


app.get("*",(req,res)=>{
  res.status(404);
  res.render("404Page");
});


app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`, app.settings.env);
});
