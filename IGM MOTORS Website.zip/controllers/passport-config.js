const LocalStrategy = require("passport-local").Strategy;
const bcrypt = require("bcrypt");
const authController = require("./AuthController");
const toastr = require('express-toastr');

async function initialize(passport, getUserByEmail, getUserById) {
  const authenticateUser = async (email, password, done) => {
    const user = await getUserByEmail(email);
    if (user == null) {
      return done(null, false, { message: "Invalid email. Please make sure your email is correct." });
    }
    try {
      if (await authController.comparePassword(password, user.password, user.salt)) {
        return done(null, user);
      } else {
        return done(null, false, { message: "Invalid password. Please make sure your password is correct." });
      }
    } catch (e) {
      return done(e);
    }
  };
  passport.serializeUser((user, done) => {
    done(null, user.id)
  });
  passport.deserializeUser(async (id, done) => {
    return done(null, await getUserById(id));
  });
  passport.use(new LocalStrategy({ usernameField: "email" }, authenticateUser));
}

module.exports = initialize;