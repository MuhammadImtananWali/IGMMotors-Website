// const flash = require("connect-flash");
const passport = require("passport");
const express = require("express");
const bcrypt = require("bcrypt");

const app = express();
const saltRounds = 10;

const cookieParser = require("cookie-parser");
const session = require('express-session');

const User = require("../models/UserModel");

app.use(cookieParser());

// For parsing application/json
app.use(express.json());

// Function to compare password.
const comparePassword = async function (inputPassword, storedHashedPassword, salt) {
  try {
    const hashedInputPassword = await bcrypt.hash(inputPassword, salt);
    const passwordsMatch = hashedInputPassword === storedHashedPassword;
    return passwordsMatch;
  } catch (error) {
    console.log("Error while comparing password:", error);
    return false;
  }
}

const login = async (Email, Password) => {
  try {
    const user = await User.findOne({ email: Email });
    
    if (user) {
      const result = await comparePassword(Password, user.password, user.salt);
      console.log("Result: ", result);
      if (result) {
        return user;
      } else {
        return false;
      }
    } else {
      return false;
    }
  } catch {
    return false;
  }
};

const register = async (req, res, next) => {
  try {
    const Salt = await bcrypt.genSalt(saltRounds);
    const hashedValue = await bcrypt.hash(req.body.password, Salt);

    console.log("hashedPassword: ",hashedValue);

    let user = new User({
      name: req.body.name,
      email: req.body.email,
      phone: parseInt(req.body.phone),
      password: hashedValue,
      salt: Salt,
    });
    console.log("User: ", user);
    await user
      .save()
      .then(function (newUser) {
        req.flash(
          "success_msg",
          "Your Account Has Been Registered, you can log in now..."
        );
        res.locals.messages = req.flash();
        console.log("Successfully saved vendor in Database");
        res.redirect("/");
      })
      .catch((error) => {
        console.log("Error Adding new User", error);
        req.flash(
          "error_msg",
          "This email already exist in our record, please go to log in page"
        );
        res.locals.messages = req.flash();
      });
  } catch (error) {
    res.render("home");
  }
};



module.exports = {
  comparePassword,
  login,
  register
};