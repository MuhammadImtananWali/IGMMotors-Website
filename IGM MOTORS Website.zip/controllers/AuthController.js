// const flash = require("connect-flash");
const passport = require("passport");
const express = require("express");
const bcrypt = require("bcrypt");

const app = express();
const saltRounds = 10;

const cookieParser = require("cookie-parser");
const session = require('express-session');

const User = require("../models/UserModel");

// const initializePassport = require("./passport-config");
// initializePassport(
//   passport,
//   (email) => User.findOne({ email: email }),
//   (id) => User.findOne({ _id: id })
// );

app.use(cookieParser());
// app.use(flash());

// For parsing application/json
app.use(express.json());

// Function to compare password.
const comparePassword = async function (inputPassword, storedHashedPassword, salt) {
  try {
    const hashedInputPassword = await bcrypt.hash(inputPassword, salt);
    console.log("hashedInputPassword: ",hashedInputPassword);
    console.log("storedHashedPassword: ",storedHashedPassword);
    console.log("salt: ",salt);
    const passwordsMatch = hashedInputPassword === storedHashedPassword;
    return passwordsMatch;
  } catch (error) {
    console.log("Error while comparing password:", error);
    return false;
  }
}

const login = async (Email, Password) => {
  try {
    const user = await User.findOne({ email: Email });
    
    if (user) {
      const result = await comparePassword(Password, user.password, user.salt);
      console.log("Result: ", result);
      if (result) {
        return user;
      } else {
        return false;
      }
    } else {
      return false;
    }
  } catch {
    return false;
  }
};

// const login = async (req, res,next) => {
//   const user = await User.findOne({ email: req.body.email });
//   if (user) {
//     const result = await comparePassword(
//       req.body.password,
//       user.password,
//       user.salt
//     );
//     if (result) {
//       req.session.user = user;
//       req.session.save();
//       req.flash("User logged in");
//       res.locals.messages = req.flash();
//       res.redirect("/");
//     } else {
//       req.flash("Password doesn't match.");
//       res.locals.messages = req.flash();
//     }
//   } else {
//     req.flash("Email not exist.");
//     res.locals.messages = req.flash();
//     next();
//   }
// };

const logout = (req, res) => {
    req.session.destroy();
    console.log("User logged out!");
};

const register = async (req, res, next) => {
    try {
      const Salt = await bcrypt.genSalt(saltRounds);
      const hashedValue = await bcrypt.hash(req.body.password, Salt);

      console.log("hashedPassword: ",hashedValue);

      let user = new User({
        name: req.body.name,
        email: req.body.email,
        phone: parseInt(req.body.phone),
        password: hashedValue,
        salt: Salt,
      });
      console.log("User: ", user);
      await user
        .save()
        .then(function (newUser) {
          req.flash(
            "success_msg",
            "Your Account Has Been Registered, you can log in now..."
          );
          res.locals.messages = req.flash();
          console.log("Successfully saved vendor in Database");
          res.redirect("/");
        })
        .catch((error) => {
          console.log("Error Adding new User", error);
          req.flash(
            "error_msg",
            "This email already exist in our record, please go to log in page"
          );
          res.locals.messages = req.flash();
        });
    } catch (error) {
      // res.json({
      //     // message: "Registered"
      //     message: "An error occurred!";

      // });
      res.render("home");
    }
};


module.exports = {
  comparePassword,
  login,
  register,
  logout,
};











// const login = (req, res, next) => {
//     var username= req.body.username
//     var password = req.body.password
//     User.findOne({$or: [{email:username}, {phone:username}]})
//     .then(user =>{
//     if(user){
//     bcrypt.compare (password, user.password, function (err, result) { {
//     if (err)
//     res.json({
//     error: err
//     })
//     }
//     if(result) {
//     let
//     token
//     jwt.sign({name:
//     user.name},
//     'verySecretValue'
//     ,
//     {expiresIn:
//     '1h'})
//     res.json({
//     message
//     : 'Login Successful!',
//     token
//     =
//     })
//     }else{
//     res.json({
//     message:"Password does not matched!"
//     })
// }
//     })
// }
// else{
//     res.json({message:"No user Found!"})
// }
//     })
