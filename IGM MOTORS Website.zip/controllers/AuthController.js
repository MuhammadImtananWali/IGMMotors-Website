// const flash = require("connect-flash");
const passport = require("passport");
const express = require("express");
const bcrypt = require("bcrypt");

const app = express();
const saltRounds = 10;

const cookieParser = require("cookie-parser");
const session = require("express-session");

const User = require("../models/UserModel");

app.use(cookieParser());

// For parsing application/json
app.use(express.json());

// Function to compare password.
const comparePassword = async function (
  inputPassword,
  storedHashedPassword,
  salt
) {
  try {
    const hashedInputPassword = await bcrypt.hash(inputPassword, salt);
    const passwordsMatch = hashedInputPassword === storedHashedPassword;
    return passwordsMatch;
  } catch (error) {
    req.toastr.error(`${error.message}`, "ERROR");
    res.status(500);
    return false;
  }
};

const register = async (req, res, next) => {
  try {
    console.log("Body:",req.body);
    if (User.find({ email: req.body.email })) {
      return res.send({ message: "Email already in-use." });
    } else {
      if (User.find({ phone: parseInt(req.body.phone) })) {
        return res.send({ message: "Phone number already in-use." });
      } else {
        const Salt = await bcrypt.genSalt(saltRounds);
        const hashedValue = await bcrypt.hash(req.body.password, Salt);
        let user = new User({
          name: req.body.name,
          email: req.body.email,
          phone: parseInt(req.body.phone),
          password: hashedValue,
          salt: Salt,
        });
        await user
          .save()
          .then(function (newUser) {
            req.toastr.success(
              "Account has been registered, You can log in now...",
              "SUCCESS"
            );
            res.status(200);
            res.redirect("/");
          })
          .catch((error) => {
            req.toastr.error("Email already in use.", "ERROR");
            res.status(400);
          });
      }
    }
  } catch (error) {
    req.toastr.error(`${error.message}`, "ERROR");
    res.status(500);
    res.redirect("/");
  }
};

module.exports = {
  comparePassword,
  register,
};
