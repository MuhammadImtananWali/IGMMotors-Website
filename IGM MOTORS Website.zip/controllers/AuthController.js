// const flash = require("connect-flash");
const passport = require("passport");
const express = require("express");
const bcrypt = require("bcrypt");

const app = express();
const saltRounds = 10;

const cookieParser = require("cookie-parser");
const session = require("express-session");

const User = require("../models/UserModel");

app.use(cookieParser());

// For parsing application/json
app.use(express.json());

// Function to compare password.
const comparePassword = async function (
  inputPassword,
  storedHashedPassword,
  salt
) {
  try {
    const hashedInputPassword = await bcrypt.hash(inputPassword, salt);
    const passwordsMatch = hashedInputPassword === storedHashedPassword;
    return passwordsMatch;
  } catch (error) {
    req.toastr.error(`${error.message}`, "ERROR");
    res.status(500);
    return false;
  }
};

const register = async (req, res, next) => {
  try {
    const inputEmail = await User.find({ email: req.body.email });
    if (inputEmail.length) {
      return res.send({ message: "Looks like this email is in use. Try logging in." });
    } else {
      const inputPhone = await User.find({ phone: parseInt(req.body.phone) });
      if (inputPhone.length) {
        return res.send({ message: "Please use a different phone number." });
      } else {
        const Salt = await bcrypt.genSalt(saltRounds);
        const hashedValue = await bcrypt.hash(req.body.password, Salt);
        let user = new User({
          name: req.body.name,
          email: req.body.email,
          phone: parseInt(req.body.phone),
          password: hashedValue,
          salt: Salt,
        });
        await user
          .save()
          .then(function (newUser) {
            req.toastr.success("Registered Successfully.\nLogin Now!!!", "SUCCESS");
            return res.send({redirect: "/"});
          })
          .catch((error) => {
            return res.status(500).send({ message: `${error.message}` });
          });
      }
    }
  } catch (error) {
    return res.status(500).send({ message: `${error.message}` });
  }
};

module.exports = {
  comparePassword,
  register,
};
