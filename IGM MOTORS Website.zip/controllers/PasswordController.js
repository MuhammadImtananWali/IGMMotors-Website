const User = require("../models/UserModel");
const RandomString = require("randomstring");
const mailer = require("../utils/mailer");
const config = require("../config/config");
const bcrypt = require("bcrypt");
const saltRounds = 10;

const forgetPassword = async (req, res) => {
  try {
    const email = req.body.email;
    const userData = await User.findOne({ email: email });
    if (userData) {
      const randomCode = RandomString.generate(6);
      await User.updateOne({ email: email }, { $set: { token: randomCode } });
      await mailer({
        From: config.AUTH_USER,
        To: email,
        Subject: "IGMMotors: Reset password.",
        message: `<p style="text-align: justify; line-height: 1.5;">Dear ${userData.name},
            <br><br>
            It seems like you forgot your password for IGMMotors. Click the link below to reset your password.
            <br><br>
            <a href="http://82.180.173.54/password/reset-password?email=${encodeURIComponent(email)}&token=${randomCode}">Reset Password</a>
            <br><br>
            If you did not forget your password, please ignore this email.
            <br><br>
            Regards,<br>
            <b>IGMMotors Team</b>
            </p>`,
      });
      req.toastr.info("Check your Email to reset password.","Email Sent");
      res.status(200).redirect("/");
    } else {
      req.toastr.error("Email doesn't exist.","ERROR");
      res.status(400).redirect("/password/forget-password");
    }
  } catch (error) {
    res.status(500).send({ success: false, msg: error.message });
  }
};

const resetPassword = async (req, res) => {
  try {
    const token = req.query.token;
    const email = req.query.email;
    if (await User.findOne({ email: email, token: token })) {
      const newPassword = req.body.newPassword;
      const Salt = await bcrypt.genSalt(saltRounds);
      const hashedValue = await bcrypt.hash(newPassword, Salt);
      await User.updateOne({ email: email, token: token }, { $set: { token: "", password: hashedValue, salt: Salt } });
      req.toastr.success("Your password has been reset successfully.","SUCCESS");
      res.status(200);
      res.redirect("/");
    } else {
      req.toastr.error("Invalid data","ERROR");
      res.status(400);
      return
    }
  } catch (error) {
    res.status(400).send({ success: false, msg: error.message });
    req.toastr.error(`${error.message}`,"ERROR");
    res.redirect("/");
  }
};

module.exports = {
  forgetPassword,
  resetPassword,
};
