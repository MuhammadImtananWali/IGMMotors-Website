const User = require("../models/UserModel");
const RandomString = require("randomstring");
const mailer = require("../utils/mailer");
const config = require("../config/config");

const forgetPassword = async (req, res) => {
  try {
    console.log("Hello --------------");
    const email = req.body.email;
    const userData = await User.findOne({ email: email });
    if (userData) {
      const randomString = RandomString.generate(6);
      await User.updateOne({ email: email }, { $set: { token: randomString } });
      mailer({
        From: config.AUTH_USER,
        To: req.body.email,
        Subject: "IGMMotors: Request for reset password",
        message: `<p style="text-align: justify; line-height: 1.5;">Dear ${userData.name},
            <br><br>
            It seems like you forgot your password for IGMMOTORS. Click <a href=\`http://localhost:3000/password/reset-password?token='${randomString}'\`>reset my password</a> to reset.
            <br><br>
            Regards,<br>
            <b>IGMMOTORS Team</b>
            </p>`,
      });
      res
        .status(200)
        .send({ success: true, msg: "Check your Email to reset password." });
        redirect("/password/reset-password");
    } else {
      res.status(200).send({ success: true, msg: "This Email doesn't exist." });
    }
  } catch (error) {
    res.status(400).send({ success: false, msg: error.message });
  }
};

const resetPassword = async (req, res) => {
  try {
  } catch (error) {}
};

module.exports = {
  forgetPassword,
  resetPassword,
};
