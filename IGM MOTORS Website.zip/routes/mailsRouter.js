const express = require("express");
var router = express.Router();

const mailer = require("../utils/mailer");

const dotenv = require("dotenv");
dotenv.config({ path: "config.env" });

const emailSubscriptionModel = require("../models/emailSubscriptionModel");

router.post("/queries", async (req, res) => {
  console.log("Body:", req.body);
  mailer({
    From: req.body.email,
    To: process.env.AUTH_USER,
    Subject: "IGMMotors Query from " + req.body.name,
    message: `<p style="text-align: justify; line-height: 1.5;">Dear IGMMOTORS Team,<br><br>
      A new query has been submitted through the IGM MOTORS website. Here are the details:<br><br>
      ${req.body.message}<br><br>Please respond to this query as soon as possible.<br><br>
       Best regards,<br>
       <b>IGMMOTORS Website Team</b></p>`,
  });
  res.redirect("/");
});

router.post("/latestSubscription", async (req, res) => {
  try {
    const Email = req.body.email;

    // Check if the email already exists in the database
    const existingSubscription = await emailSubscriptionModel.findOne({
      email: Email,
    });

    if (existingSubscription) {
      // Email already subscribed, handle accordingly
      return res.status(400).json({ message: "Email is already subscribed." });
    }

    // Create a new subscription entry
    const newSubscription = new emailSubscriptionModel({
      email: Email,
    });

    // Save the subscription to the database
    await newSubscription.save();
    mailer({
      To: Email,
      From: process.env.AUTH_USER,
      Subject: "Thank You for Subscribing to IGM MOTORS Updates!",
      message: `<p style="text-align: justify; line-height: 1.5;">Dear Subscriber,<br><br>Thank you for subscribing to the latest updates from IGM MOTORS! We are thrilled to have
           you as part of our community, and we can't wait to keep you informed about all the exciting
            developments in the world of automobiles.<br><br>
            Thank you once again for choosing IGM MOTORS. We look forward to sharing our passion 
            for automobiles with you.<br><br>
            Best regards,<br>
            <b>The IGM MOTORS Team</b></p>`,
    });

    // Return a success response
    res.status(201).json({ message: "Email subscription successful." });
  } catch (error) {
    // Handle any errors that occur during the subscription process
    console.error(error);
    res.status(500).json({ message: "Internal server error." });
  }
});

module.exports = router;
