const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
var router = express.Router();

const mailer = require("../utils/mailer");

router.post("/", async (req, res) => {
    console.log("Body:",req.body);
    mailer(req.body);
    res.redirect("/");
});

module.exports = router;