const express = require("express");
const path = require("path");
var hbs = require("hbs");
const router = express.Router();
const passport = require('passport');
const authScript = require("../static/js/authScript");

const AuthController  = require("../controllers/AuthController")
const partialPath = path.join(__dirname, "./views/partials");

hbs.registerPartials(partialPath);


router.post("/login",checkNotAuthenticated, function(req, res, next) {
  passport.authenticate( "local",{successRedirect: '/'}, function(err, user, info) {
    if (err) { return next(err) }
    if (!user) {
      return res.send({ message: info.message });
    }

    req.login(user, (err) => {
      if (err) {
        return next(err);
      }
      // Successful login
      return res.json({ redirect: "/" });
    });
  })(req, res, next);
})

// Register a new user.
router.post("/register", checkNotAuthenticated, AuthController.register);

// Logout the current user.
router.post("/logout", (req, res) => {
  req.logOut(() => {
    res.redirect("/");
  });
});


function checkNotAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return res.redirect("/Vehicles_Dashboard");
  }
  next();
}

module.exports = router;