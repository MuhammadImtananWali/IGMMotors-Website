const express = require("express");
const router = express.Router();
const User = require("../models/UserModel");
const passwordController = require("../controllers/PasswordController");

function checkAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        res.render("404Page");
    }
    return next();
  }

// Get forget password page.
router.get("/forget-password", checkAuthenticated, (req, res) => {
  res.render("ForgetPasswordPage");
});

router.post("/forget-password", checkAuthenticated, passwordController.forgetPassword);

// Get reset password page.
router.get("/reset-password", checkAuthenticated, async (req, res) => {
  try {
    const token = req.query.token;
    const email = req.query.email;
    if (await User.findOne({ email: email, token: token }) && token != "") {
        res.render("ResetPasswordPage");
    } else {
      req.toastr.error("Invalid data.","ERROR");
      res.status(400);
      res.render("404Page");
    }
  } catch (error) {
    res.status(500).send({ success: false, msg: error.message });
  }
});

router.post("/reset-password", checkAuthenticated, passwordController.resetPassword);

router.get("*", (req, res) => {
  res.status(404);
  res.render("404Page");
});

module.exports = router;
