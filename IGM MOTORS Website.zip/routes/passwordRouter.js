const express = require("express");
const router = express.Router();
const passwordController = require("../controllers/PasswordController");

// Forget password
router.post("/forget-password",passwordController.forgetPassword);
router.get("/forget-password",(req, res)=>{
    console.log("hello----------");
    res.render("ForgetPasswordPage");
});


module.exports = router;