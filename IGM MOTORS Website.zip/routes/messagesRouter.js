const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const router = express.Router();

const http = require('http').Server(app);
const io = require('socket.igo')(http);

const Message = require("../models/MessageModel");



router.get("/messages", (req, res) => {
  Message.find({}, (err, messages) => {
    res.send(messages);
  });
});

router.post("/messages", (req, res) => {
  var message = new Message(req.body);
  message.save((err) => {
    if (err) sendStatus(500);
    io.emit("message", req.body);
    res.sendStatus(200);
  });
});

io.on("connection", () => {
  console.log("a user is connected");
});

module.exports = router;
