const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
var router = express.Router();
const app = express();

const Vehicle = require("../models/VehicleModel");
const Image = require("../models/ImagesModel");

const staticPath = path.join(__dirname, "../static");

// Set static folder path to use static files like JS,CSS,images
router.use("/static", express.static(staticPath));

// This function fetch images from DB and add image data to vehicles.
async function fetchImagesAndMap(vehicles) {
  // Fetch associated images for all vehicles
  const vehicleIds = vehicles.map((vehicle) => vehicle._id);
  const imageMap = {}; // Map to store image data

  const images = await Image.find({ vehicle: { $in: vehicleIds } });
  images.forEach((image) => {
    const base64Data = image.imageData.data.toString("base64");
    imageMap[image.vehicle.toString()] = {
      contentType: image.imageData.contentType,
      data: base64Data,
    };
  });

  // Add image data to each vehicle in items
  const items = vehicles.map((vehicle) => {
    return {
      ...vehicle.toObject(),
      imageData: imageMap[vehicle._id.toString()] || null,
    };
  });

  return items;
}

router.get("/:type", async (req, res) => {
  try {
    const validTypes = ["car", "bike", "truck", "boat"];

    if (validTypes.includes(req.params.type)) {
      // Fetch vehicles of the specified type
      const vehicles = await Vehicle.find({ type: req.params.type });

      const items = await fetchImagesAndMap(vehicles);
      if (req.isAuthenticated()) {
        flag = true;
      }
      else{
        flag = false;
      }
      res.render("Vehicles_Dashboard", { models: items , loginCheck: flag });
    } else {
      res.status(404);
      res.render("404Page");
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Error retrieving items from MongoDB" });
  }
});

// GET Filtering vehicles
router.get("/*/filter", async function (req, res) {
  const validTypes = ["car", "bike", "truck", "boat"];
  var currentUrl = req.url;
  var parts = currentUrl.split("/"); // Split the URL by '/'
  if (validTypes.includes(parts[1])) {
    let filtered_models;

    // Sorting
    const sortBy = req.query.sortBy;
    if (sortBy == "latest") {
      filtered_models = await Vehicle.find({ type: parts[1] }).sort({
        year: -1,
      });
    } else if (sortBy == "highprice") {
      filtered_models = await Vehicle.find({ type: parts[1] }).sort({
        price: -1,
      });
    } else if (sortBy == "lowprice") {
      filtered_models = await Vehicle.find({ type: parts[1] }).sort({
        price: 1,
      });
    }

    // Price Filtering
    const priceBy = req.query.priceBy;
    if (priceBy != undefined) {
      const priceLt = priceBy.slice(5) + "000";
      filtered_models = await Vehicle.find({
        type: parts[1],
        price: { $lte: priceLt },
      }).sort({ price: -1 });
    }

    // Year Filtering
    var year = req.query.year;
    if (year != undefined) {
      year = year.slice(4);
      filtered_models = await Vehicle.find({ type: parts[1], year: year });
    }

    var yearLt = req.query.yearLt;
    if (yearLt != undefined) {
      yearLt = yearLt.slice(4);
      filtered_models = await Vehicle.find({
        type: parts[1],
        year: { $lte: yearLt },
      });
    }

    const items = await fetchImagesAndMap(filtered_models);

    res.render("Vehicles_Dashboard", { models: items });
  }
});

module.exports = router;