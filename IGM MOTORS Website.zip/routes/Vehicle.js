const express = require("express");
const path = require("path");
var router = express.Router();

const appJSFile = require("../app");

const Vehicle = require("../models/VehicleModel");
const Image = require("../models/ImagesModel");
const Message = require("../models/MessageModel");

const staticPath = path.join(__dirname, "../static");

// Set static folder path to use static files like JS,CSS,images
router.use("/static", express.static(staticPath));

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.render("404Page");
}

// This function fetch all the locations from DB.
async function getAllLocations() {
  const locations = await Vehicle.distinct("location");
  return locations;
}

// This function fetch images from DB and add image data to vehicles.
async function fetchImagesAndMap(vehicles) {
  const vehicleIds = vehicles.map((vehicle) => vehicle._id);
  let imageMap = {}; // Map to store image data

  const images = await Image.find({ vehicle: { $in: vehicleIds } });

  // Group images by vehicle ID
  images.forEach((image) => {
    const base64Data = image.imageData.data.toString("base64");
    if (!imageMap[image.vehicle.toString()]) {
      imageMap[image.vehicle.toString()] = [];
    }
    imageMap[image.vehicle.toString()].push({
      contentType: image.imageData.contentType,
      data: base64Data,
    });
  });

  // Add image data to each vehicle in items
  const items = vehicles.map((vehicle) => {
    return {
      ...vehicle.toObject(),
      imageData: imageMap[vehicle._id.toString()] || [],
    };
  });
  return items;
}

router.get("/:type", async (req, res) => {
  try {
    const validTypes = ["car", "bike", "truck", "boat"];

    if (validTypes.includes(req.params.type)) {
      let uniqueRecordsArray = null;
      // Fetch vehicles of the specified type
      const vehicles = await Vehicle.find({ type: req.params.type });

      const items = await fetchImagesAndMap(vehicles);
      const locations = await getAllLocations();

      if (req.isAuthenticated()) {
        uniqueRecordsArray = await appJSFile.getAllMessages(
          req.session.passport.user
        );
        flag = true;
      } else {
        flag = false;
      }
      res.render("Vehicles_Dashboard", {
        models: items,
        loginCheck: flag,
        vehicleType: req.params.type,
        locations: locations,
        Messages: uniqueRecordsArray,
      });
    } else {
      res.status(404);
      res.render("404Page");
    }
  } catch (error) {
    req.toastr.error(`${error.message}`, "ERROR");
    res.status(500);
  }
});

// GET Filtering vehicles
router.get("/*/filter", async function (req, res) {
  try {
    const validTypes = ["car", "bike", "truck", "boat"];
    var currentUrl = req.url;
    var parts = currentUrl.split("/"); // Split the URL by '/'
    if (validTypes.includes(parts[1])) {
      let filtered_models;

      // Sorting
      const sortBy = req.query.sortBy;
      if (sortBy == "latest") {
        filtered_models = await Vehicle.find({ type: parts[1] }).sort({
          year: -1,
        });
      } else if (sortBy == "highprice") {
        filtered_models = await Vehicle.find({ type: parts[1] }).sort({
          price: -1,
        });
      } else if (sortBy == "lowprice") {
        filtered_models = await Vehicle.find({ type: parts[1] }).sort({
          price: 1,
        });
      }

      // Price Filtering
      const priceBy = req.query.priceBy;
      if (priceBy != undefined) {
        const priceLt = priceBy.slice(5) + "000";
        filtered_models = await Vehicle.find({
          type: parts[1],
          price: { $lte: priceLt },
        }).sort({ price: -1 });
      }

      // Body Type Filtering
      var BodyType = req.query.bodyType;
      if (BodyType != undefined) {
        filtered_models = await Vehicle.find({
          type: parts[1],
          bodyType: BodyType,
        });
      }

      // Vehicle Condition Filtering
      var vehicleCondition = req.query.vehicleCondition;
      if (vehicleCondition != undefined) {
        filtered_models = await Vehicle.find({
          type: parts[1],
          vehicleCondition: vehicleCondition,
        });
      }

      // Location Filtering
      var location = req.query.location;
      if (location != undefined) {
        filtered_models = await Vehicle.find({
          type: parts[1],
          location: location,
        });
      }

      // Make Filtering
      var Make = req.query.make;
      if (Make != undefined) {
        filtered_models = await Vehicle.find({
          type: parts[1],
          make: Make,
        });
      }

      // Model Filtering
      var Model = req.query.model;
      if (Model != undefined) {
        filtered_models = await Vehicle.find({
          type: parts[1],
          model: Model,
        });
      }

      // Year Filtering
      var year = req.query.year;
      if (year != undefined) {
        year = year.slice(4);
        filtered_models = await Vehicle.find({ type: parts[1], year: year });
      }

      var yearLt = req.query.yearLt;
      if (yearLt != undefined) {
        yearLt = yearLt.slice(4);
        filtered_models = await Vehicle.find({
          type: parts[1],
          year: { $lte: yearLt },
        });
      }

      const items = await fetchImagesAndMap(filtered_models);
      const locations = await getAllLocations();

      res.render("Vehicles_Dashboard", {
        models: items,
        vehicleType: parts[1],
        locations: locations,
      });
    }
  } catch (error) {
    req.toastr.error(`${error.message}`, "ERROR");
    res.status(500);
  }
});

router.get("/*/Vehicle_Page/:id", async function (req, res) {
  try {
    let modelId = req.params.id;
    let imageMap = {}; // Map to store image data
    let uniqueRecordsArray = null;
    let currentUser = null;

    let vehicleModel = await Vehicle.findById(modelId).populate("owner").exec();
    const images = await Image.find({ vehicle: modelId });

    // Group images by vehicle ID
    images.forEach((image) => {
      const base64Data = image.imageData.data.toString("base64");
      if (!imageMap[image.vehicle.toString()]) {
        imageMap[image.vehicle.toString()] = [];
      }
      imageMap[image.vehicle.toString()].push({
        contentType: image.imageData.contentType,
        data: base64Data,
      });
    });

    const item = {
      ...vehicleModel.toObject(),
      imageData: imageMap[vehicleModel._id.toString()] || [],
    };
    if (item.isElectric === true) {
      item.isElectric = "Yes";
    } else if (item.isElectric === false) {
      item.isElectric = "No";
    }

    if (req.isAuthenticated()) {
      uniqueRecordsArray = await appJSFile.getAllMessages(
        req.session.passport.user
      );
      flag = true;
      currentUser = req.session.passport.user;
    } else {
      flag = false;
      currentUser = null;
    }
    res.render("Vehicle_Page", {
      model: item,
      loginCheck: flag,
      currentUser: currentUser,
      Messages: uniqueRecordsArray,
    });
  } catch (error) {
    req.toastr.error(`${error.message}`,"ERROR");
    res.status(500);
  }
});

// Chat app
// router.get("/*/ChatApp", checkAuthenticated, (req, res) => {
//   try {
//     const parts = req.url.split("/");
//     if (parts[parts.length - 2] != req.session.passport.user) {
//       res.render("Chat_App", {
//         sessionId: req.session.passport.user,
//       });
//     }
//   } catch (error) {
//     req.toastr.error(`${error.message}`,"ERROR");
//     res.status(500);
//   }
// });

module.exports = router;
