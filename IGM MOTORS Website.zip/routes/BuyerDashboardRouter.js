var express = require('express');
const mongoose = require('mongoose');
const path = require("path");
const multer = require("multer");

var router = express.Router();

const User = require('../models/UserModel');
const Vehicle = require('../models/VehicleModel');
const Image = require('../models/ImagesModel');
const staticPath = path.join(__dirname, "../static");

// Set static folder path to use static files like JS,CSS,images
router.use("/static", express.static(staticPath));

const storage = multer.memoryStorage();
const upload = multer({storage: storage})

// This function fetch images from DB and add image data to vehicles.
async function fetchImagesAndMap(vehicles) {
  // Fetch associated images for all vehicles
  const vehicleIds = vehicles.map((vehicle) => vehicle._id);
  const imageMap = {}; // Map to store image data

  const images = await Image.find({ vehicle: { $in: vehicleIds } });
  images.forEach((image) => {
    const base64Data = image.imageData.data.toString("base64");
    imageMap[image.vehicle.toString()] = {
      contentType: image.imageData.contentType,
      data: base64Data,
    };
  });

  // Add image data to each vehicle in items
  const items = vehicles.map((vehicle) => {
    return {
      ...vehicle.toObject(),
      imageData: imageMap[vehicle._id.toString()] || null,
    };
  });

  return items;
}

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }

  res.render("404Page");
}

router.get("/", checkAuthenticated, async function (req, res) {
  let vehicles_List = await Vehicle.find();
  const items = await fetchImagesAndMap(vehicles_List);
  // let user_List = await User.find();
  // console.log(await Vehicle.findOne({ owner: user_List[0].id }));
  if (req.isAuthenticated()) {
    flag = true;
  }
  else{
    flag = false;
  }
  res.render("BuyersDashboard", { models: items , loginCheck: flag });
});

// POST Vehicle Form Page
router.post('/addVehicle', upload.single('image'), async function (req, res) {

  let vehicle = new Vehicle({
    type:req.body.vehicleType,
    make:req.body.name,
    model: req.body.model,
    year:req.body.year,
    price:req.body.price,
    color:req.body.colour,
    description:req.body.description,
    owner:"64da5f6903e0975f46e78951",
    isElectric: req.body.isElectricCar === "yes",
  });

  let image = new Image({
    vehicle: vehicle.id,
    imageData: {
      data: req.file.buffer,
      contentType: req.file.mimetype
    }
  });

  await vehicle.save();
  await image.save();

  res.redirect('/Buyer-Dashboard');
});

// Delete Vehicle
router.get("/deleteVehicle/:id", async function (req, res) {
  result = await Vehicle.findByIdAndRemove(req.params.id);
  console.log(result);
  result = await Image.findByIdAndRemove(req.params.id);

  // Removing records based on a specific column (e.g., make)
  // Convert the string ID to ObjectId
  const vehicleId = new mongoose.Types.ObjectId(req.params.id);
  Image.findOneAndDelete({ vehicle: vehicleId })
  .then((deletedImage) => {
    if (deletedImage) {
      console.log("Image deleted successfully");
      res.status(200);
    } else {
      console.log("Image not found");
      res.status(404);
    }
  })
  .catch((error) => {
    console.error("An error occurred:", error);
    res.status(500);
  });
  res.redirect("/Buyer-Dashboard");
});

module.exports = router;