var express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const multer = require("multer");

var router = express.Router();

const User = require("../models/UserModel");
const Vehicle = require("../models/VehicleModel");
const Image = require("../models/ImagesModel");
const staticPath = path.join(__dirname, "../static");

// Set static folder path to use static files like JS,CSS,images
router.use("/static", express.static(staticPath));

const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// This function fetch images from DB and add image data to vehicles.
async function fetchImagesAndMap(vehicles) {
  // Fetch associated images for all vehicles
  const vehicleIds = vehicles.map((vehicle) => vehicle._id);
  const imageMap = {}; // Map to store image data

  const images = await Image.find({ vehicle: { $in: vehicleIds } });
  images.forEach((image) => {
    const base64Data = image.imageData.data.toString("base64");
    imageMap[image.vehicle.toString()] = {
      contentType: image.imageData.contentType,
      data: base64Data,
    };
  });

  // Add image data to each vehicle in items
  const items = vehicles.map((vehicle) => {
    return {
      ...vehicle.toObject(),
      imageData: imageMap[vehicle._id.toString()] || null,
    };
  });

  return items;
}

function checkAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next();
  }

  res.render("404Page");
}

const generateDiscription = (Vehicle) => {
  // Construct the description template
  let description = `This ${Vehicle.year} ${Vehicle.make} ${Vehicle.model} is a ${Vehicle.bodyType} vehicle, located in ${Vehicle.location}. It is priced at $${Vehicle.price} and is currently in ${Vehicle.vehicleCondition} condition. The exterior color is ${Vehicle.color}.`;

  if (Vehicle.isElectric) {
    description += ` It is an electric vehicle, which means it does not require traditional fuel.`;
  } else {
    description += ` It runs on ${Vehicle.fuelType} fuel.`;
  }

  description += `\nThis ${Vehicle.bodyType} comes with a range of features including ${Vehicle.features}. 
Whether you're commuting or going on a road trip, this vehicle has you covered.`;

  return description;
};

router.get("/", checkAuthenticated, async function (req, res) {
  let vehicles_List = await Vehicle.find({ owner: req.session.passport.user });
  const items = await fetchImagesAndMap(vehicles_List);
  if (req.isAuthenticated()) {
    flag = true;
  } else {
    flag = false;
  }
  res.render("BuyersDashboard", { models: items, loginCheck: flag });
});

// POST Vehicle Form Page
router.post("/addVehicle", upload.single("image"), async function (req, res) {
  let vehicle = new Vehicle({
    type: req.body.vehicleType,
    make: req.body.name,
    model: req.body.model,
    year: req.body.year,
    price: req.body.price,
    bodyType: req.body.bodyType[0],
    location: req.body.location,
    features: req.body.features,
    fuelType: req.body.fuelType,
    vehicleCondition: req.body.vehicleCondition,
    color: req.body.colour,
    description: "",
    owner: req.session.passport.user,
    isElectric: false,
  });

  const desc  = generateDiscription(vehicle);

  vehicle.description = desc;
  vehicle.isElectric = vehicle.bodyType === "electric_car";

  let image = new Image({
    vehicle: vehicle.id,
    imageData: {
      data: req.file.buffer,
      contentType: req.file.mimetype,
    },
  });


  console.log(typeof toString(req.body.bodyType));
  console.log(toString(req.body.bodyType));
  console.log("----------------------");
  console.log(vehicle);
  console.log("----------------------");
  console.log(typeof vehicle.bodyType);
  console.log(vehicle.bodyType);
  console.log(typeof "electric_car");
  
  await vehicle.save();
  await image.save();

  res.redirect("/Buyer-Dashboard");
});

// Delete Vehicle
router.get("/deleteVehicle/:id", async function (req, res) {
  result = await Vehicle.findByIdAndRemove(req.params.id);
  result = await Image.findByIdAndRemove(req.params.id);

  // Removing records based on a specific column (e.g., make)
  // Convert the string ID to ObjectId
  const vehicleId = new mongoose.Types.ObjectId(req.params.id);
  Image.findOneAndDelete({ vehicle: vehicleId })
    .then((deletedImage) => {
      if (deletedImage) {
        res.status(200);
      } else {
        res.status(404);
      }
    })
    .catch((error) => {
      res.status(500);
    });
  res.redirect("/Buyer-Dashboard");
});

module.exports = router;
