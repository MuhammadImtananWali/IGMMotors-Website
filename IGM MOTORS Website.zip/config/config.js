const config = {
    AUTH_USER: "contact.imtanan@gmail.com",
    AUTH_PASS: "ithacffqfeiuggkj"
}

module.exports = config;