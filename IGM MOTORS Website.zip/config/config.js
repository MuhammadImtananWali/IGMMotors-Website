const config = {
    AUTH_USER: "contact.imtanan@gmail.com",
    AUTH_PASS: "cfd@2878"
}

module.exports = config;