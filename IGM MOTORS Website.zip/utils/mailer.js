const nodemailer = require("nodemailer");
const dotenv = require('dotenv');
const config = require("../config/config");

dotenv.config({ path: 'config.env'})

async function sendEmail(clientDetails) {
    var htmlTemp = clientDetails.message;
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      requireTLS:true,
      auth: {
        user: config.AUTH_USER,
        pass: config.AUTH_PASS,
      },
    });

    var mailOptions = {
        to: clientDetails.To,
        from: clientDetails.From,
        subject: clientDetails.Subject,
        html: htmlTemp
    };

    try {
        await transporter.sendMail(mailOptions);
    } catch (error) {
        return false
    }
    return true;
}

module.exports = sendEmail;