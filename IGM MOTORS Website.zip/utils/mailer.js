const nodemailer = require("nodemailer");
const dotenv = require('dotenv');
const config = require("../config/config");

dotenv.config({ path: 'config.env'})

async function sendEmail(clientDetails) {
    var htmlTemp = clientDetails.message;
    // var htmlTemp = '<h4>Dear Customer, Vehicle service is now completed. Visit the garage to drive your vehicle back</h4>'
    const transporter = nodemailer.createTransport({
      // service: "gmail",
      host: 'smtp.gmail.com',
      port: 465,
      secure: true,
      requireTLS:true,
      auth: {
        user: config.AUTH_USER,
        pass: config.AUTH_PASS,
      },
    });

    var mailOptions = {
        to: clientDetails.To,
        from: clientDetails.From,
        subject: clientDetails.Subject,
        html: htmlTemp
    };

    try {
        let info = await transporter.sendMail(mailOptions);
        console.log("Mailer Response - ", info.response);
    } catch (error) {
        console.log(error);
        return false
    }
    return true;
}

module.exports = sendEmail;