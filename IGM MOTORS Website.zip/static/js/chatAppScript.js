// Get DOM elements in respective Js variables
const form = document.getElementById("send-container");
const messageInput = document.getElementById("messageInp");
const messageContainer = document.getElementById("messageContainer");

// Function which will append event info to the contaner
const append = (message, position) => {
  const messageElement = document.createElement("div");
  messageElement.innerText = message;
  messageElement.classList.add("message");
  messageElement.classList.add(position);
  messageContainer.append(messageElement);
};

function scrollChat() {
    $("#messageContainer").animate(
    {
      scrollTop:
        $("#messageContainer").offset().top +
        $("#messageContainer")[0].scrollHeight,
    },
    0
  );
}
document.addEventListener("DOMContentLoaded", function () {
  $(document).on("click", ".messagesLI", function (e) {
    e.preventDefault();
    var idParts = $(this).attr("id").split("_");
    var senderId = idParts[0];
    var receiverId = idParts[1];
    var chatDialog = document.getElementById("chatBox");
    if (chatDialog) {
      $(".popover").popover("hide");
      chatDialog.style.display = "block";
      chatDialog.setAttribute("data-senderId", senderId);
      chatDialog.setAttribute("data-receiverId", receiverId);
      socket.emit("existingChat", senderId, receiverId);
    }
  });
  document
    .getElementById("chatCloseBtn")
    .addEventListener("click", function () {
      var chatDialog = document.getElementById("chatBox");
      if (chatDialog) {
        chatDialog.style.display = "none";
      }
    });
  var socket = io();
  // If server sends a message, receive it
  socket.on("loadNewChat", function (message, position) {
    append(`${message}`, position);
  });

  socket.on("loadAllChats", (chats, senderId, receiverID) => {
    messageContainer.innerHTML = "";
    for (let index = 0; index < chats.length; index++) {
      const chat = chats[index];
      let addClass = "";
      if (chat["sender_id"] == senderId) {
        addClass = "right";
      } else if (chat["sender_id"] == receiverID) {
        addClass = "left";
      }
      append(chat["message"], addClass);
    }
    scrollChat();
  });
  // If the form gets submitted, send server the message
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const message = messageInput.value;
    if (message) {
      var chatDialog = document.getElementById("chatBox");
      let senderId = chatDialog.getAttribute("data-senderId");
      let receiverId = chatDialog.getAttribute("data-receiverId");
      if (receiverId) {
        fetch(`/getMessages?receiverID=${receiverId}&message=${message}`);
        socket.emit("send", receiverId, message);
        append(message, "right");
        messageInput.value = "";
        scrollChat();
      }
    }
  });
});
