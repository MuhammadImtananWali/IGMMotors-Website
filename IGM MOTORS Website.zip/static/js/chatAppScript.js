// var socket = io();
// // Get DOM elements in respective Js variables
// const form = document.getElementById("send-container");
// const messageInput = document.getElementById("messageInp");
// const messageContainer = $(".container");

// var receiver_Id;

// // Function which will append event info to the contaner
// const append = (message, position) => {
//   const messageElement = document.createElement("div");
//   messageElement.innerText = message;
//   messageElement.classList.add("message");
//   messageElement.classList.add(position);
//   messageContainer.append(messageElement);
// };

// function getReceiverID() {
//   var currentUrl = window.location.href;
//   var parts = currentUrl.split("/"); // Split the URL by '/'
//   var index = parts.indexOf(parts[parts.length - 2]);

//   receiver_Id = parts[index];
//   return {parts, index}
// }

// function scrollChat() {
//   messageContainer.animate({
//     scrollTop: messageContainer.offset().top + messageContainer[0].scrollHeight
//   },0)
// }
// // Ask new user for his/her name and let the server know
// // const name = prompt("Enter your name to join");
// // socket.emit('new-user-joined', name);

// // If a new user joins, receive his/her name from the server
// socket.on("user-joined", (name) => {
//   append(`${name} joined the chat`, "right");
// });

// // If server sends a message, receive it
// socket.on('loadNewChat',function(message, position) {
//   append(`${message}`, position);
// });

// socket.on("loadAllChats", (chats) => {
//   messageContainer.innerHTML = "";
//   var sender_id = messageContainer.attr('data-id');
//   for (let index = 0; index < chats.length; index++) {
//     const chat = chats[index];
//     let addClass = "";
//     console.log(chat["sender_id"],`---${index}----`,typeof chat["sender_id"]);
//     console.log(sender_id,`---${index}----`,typeof sender_id);
//     if (chat["sender_id"] == sender_id) {
//       addClass = "right";
//     } else if (chat["sender_id"] == receiver_Id) {
//       addClass = "left";
//     }
//     append(chat["message"], addClass);
//   }
//   scrollChat()
// });

// document.addEventListener("DOMContentLoaded", function () {
//   getReceiverID()
//   socket.emit("existingChat",receiver_Id);
//   // If the form gets submitted, send server the message
//   form.addEventListener("submit", (e) => {
//     e.preventDefault();
//     const message = messageInput.value;
//     if (message) {
//       const {parts, index} = getReceiverID()
//       if (receiver_Id) {
//         fetch(
//           `/Vehicles_Dashboard/${
//             parts[index - 1]
//           }/${receiver_Id}/ChatApp/messages?receiverID=${receiver_Id}&message=${message}`
//         );
//         console.log("Message", message);
//         socket.emit("send", receiver_Id, message);
//         // socket.emit("existingChat");
//         append(message, "right");
//         scrollChat()
//         messageInput.value = "";
//       }
//     }
//   });
// });