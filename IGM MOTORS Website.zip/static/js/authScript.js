const showLoginModal = () => {
  console.log("Hello");
  const loginButton = document.querySelector("#login-btn");
  loginButton.click();
};
