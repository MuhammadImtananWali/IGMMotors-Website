// Reusable function for filtering and redirection
function filterAndRedirect(queryParam, paramValue) {
  var currentUrl = window.location.href;

  var parts = currentUrl.split("/"); // Split the URL by '/'
  var index = parts.indexOf("Vehicles_Dashboard"); // Find the index of "Vehicles_Dashboard"

  if (index !== -1 && index < parts.length - 1) {
    const validTypes = ["car", "bike", "truck", "boat"];
    if (validTypes.includes(parts[index + 1])) {
      var nextPart = parts[index + 1]; // Get the element after "Vehicles_Dashboard"
      var requestUrl =
        "/Vehicles_Dashboard/" +
        nextPart +
        "/filter?" +
        queryParam +
        "=" +
        paramValue;
      window.location.href = requestUrl;
    }
  } else {
    window.location.href = "/404Page"; // Redirect to the 404 page
  }
}

// Price Filtering
$(".form-check-input").click((clicked) => {
  var queryParam = "priceBy";
  var paramValue = clicked.target.id;
  filterAndRedirect(queryParam, paramValue);
});

price_filter_range = $("#formControlRangePrice");
price_filter_range.change(() => {
  var queryParam = "priceBy";
  var paramValue = "under" + price_filter_range.val();
  filterAndRedirect(queryParam, paramValue);
});

// Year Filtering
year_filter = $(".custom-control-input");
year_filter.change((changed) => {
  var queryParam = "year";
  var paramValue = changed.target.id;
  filterAndRedirect(queryParam, paramValue);
});

year_filter_range = $("#formControlRangeYear");
year_filter_range.change(() => {
  var queryParam = "yearLt";
  var paramValue = "year" + year_filter_range.val();
  filterAndRedirect(queryParam, paramValue);
});

// Sorting Dropdown Menu Filtering
document.getElementById("sortingDropdownMenuBtn").onclick = function () {
  $(".dropdown").on("click", ".dropdown-item", function (event) {
    var queryParam = "sortBy";
    var paramValue = event.target.id;
    filterAndRedirect(queryParam, paramValue);
  });
};

// Body Type Dropdown Menu Filtering
document.getElementById("bodyTypeDropdownMenuBtn").onclick = function () {
  $(".dropdown").on("click", ".dropdown-item", function (event) {
    var queryParam = "bodyType";
    var paramValue = event.target.id;
    filterAndRedirect(queryParam, paramValue);
  });
};

// Vehicle Condition Dropdown Menu Filtering
document.getElementById("vehicleConditionDropdownBtn").onclick = function () {
    $(".dropdown").on("click", ".dropdown-item", function (event) {
      var queryParam = "vehicleCondition";
      var paramValue = event.target.id;
      filterAndRedirect(queryParam, paramValue);
    });
  };

// Location Dropdown Menu Filtering
document.getElementById("locationDropdownBtn").onclick = function () {
  $(".dropdown").on("click", ".dropdown-item", function (event) {
    var queryParam = "location";
    var paramValue = event.target.id;
    filterAndRedirect(queryParam, paramValue);
  });
};

// Zip code Dropdown Menu Filtering
document.getElementById("zipCodeDropdownBtn").onclick = function () {
  $(".dropdown").on("click", ".dropdown-item", function (event) {
    var queryParam = "zipCode";
    var paramValue = event.target.id;
    filterAndRedirect(queryParam, paramValue);
  });
};

function search(type) {
  const searchField = document.getElementById(
    type === "make" ? "makeSearchField" : "modelSearchField"
  );
  const queryParam = type;
  const paramValue = searchField.value.trim();
  const validPattern = /^[A-Za-z\-]+(?: [A-Za-z\-]+)*$/;

  if (paramValue && validPattern.test(paramValue)) {
    filterAndRedirect(queryParam, paramValue);
  }
}

// Call search for make
function searchMake() {
  search("make");
}

// Call search for model
function searchModel() {
  search("model");
}

//  To display see more
document.addEventListener("DOMContentLoaded", function () {
  const textContainers = document.querySelectorAll(".info-third");

  textContainers.forEach(function (container) {
    const text = container.querySelector(".text");
    const seeMoreLink = container.querySelector(".see-more");

    if (text.scrollHeight > text.clientHeight) {
      seeMoreLink.style.display = "block";

      seeMoreLink.addEventListener("click", function (e) {
        e.preventDefault();
        container.classList.toggle("expanded");
        seeMoreLink.style.display = "none";
      });
    }
  });
});
