
let navbar = document.querySelector('.navbar');