
let navbar = document.querySelector('.navbar');



// window.onscroll = () => {

//     if (window.scrollY > 0) {
//         document.querySelector('.header').classList.add('active');
//     } else {
//         document.querySelector('header').classList.remove('active');
//     }

//     menubtn.classList.remove('fa-xmark');
//     navbar.classList.remove('active');
// }

// window.onload = () => {

//     if (window.scrollY > 0) {
//         document.querySelector('.header').classList.add('active');
//     } else {
//         document.querySelector('header').classList.remove('active');
//     }
// }


// document.querySelector('.home').onmousemove = (e) => {

//     document.querySelectorAll('.home-parallax').forEach(element => {
//         let speed = element.getAttribute('data-speed');

//         let x = (window.innerWidth - e.pageX * speed) / 90;
//         let y = (window.innerHeight - e.pageY * speed) / 90;

//         element.style.transform = `translateX(${y}px) translateY(${x}px)`;

//     });
// };

// document.querySelector('.home').onmouseleave = () => {

//     document.querySelectorAll('.home-parallax').forEach(element => {

//         element.style.transform = `translateX(0px) translateY(0px)`;

//     });
// };

if(document.querySelector('.wraper-box') != null)
{
    let wrapper = document.querySelector('.wraper-box');
    let activeBox = wrapper.querySelectorAll('.box');
    let activeLable = document.querySelector('.activeCircle').querySelectorAll('.fa-circle')
    let nextBtn = document.querySelector('#nextBtn');
    let preBtn = document.querySelector('#preBtn');
    let imgInd = 0;

    nextBtn.onclick = ()=>{
        imgInd++;
        changeBox();
    }

    preBtn.onclick = ()=>{
        imgInd--;
        changeBox();
    }

    let changeBox = () =>{
        
        if(imgInd > activeBox.length - 1){
            imgInd = 0;
        } else if(imgInd < 0){
            imgInd = activeBox.length - 1;
        }

        for(let i = 0; i < activeBox.length; i++){
            if(i === imgInd){
                activeBox[i].classList.add('active');
                if(window.screen.width > 450){
                    wrapper.style.transform = `translateX(${imgInd * -300}px)`;
                }
                
            } else{            
                activeBox[i].classList.remove('active');
            }
        }
    }
}

// Assuming you're using jQuery for simplicity
// $(document).on('click', '#viewPhoneBtn', async function() {
//   const ownerId = $(this).data('owner-id');
  
//   try {
//     const phoneNumber = await getUserPhoneNumber(ownerId);
//     $('#phoneNumber').text(phoneNumber);
//   } catch (error) {
//     console.error('Error fetching phone number:', error);
//     $('#phoneNumber').text('Error fetching phone number');
//   }
// });

// const User = require("../../models/UserModel");
// async function getUserPhoneNumber(ownerID) {w
//   try {
//     const user = await User.findById(ownerID);
//     if (user) {
//       return user.phone;
//     } else {
//       throw new Error('User not found');
//     }
//   } catch (error) {
//     throw new Error('Error fetching user:', error);
//   }
// }