const mongoose = require('mongoose');

const imageSchema = new mongoose.Schema({
  vehicle: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true },
  imageData: { type: Buffer, required: true }
});

const ImageModel = mongoose.model('Image', imageSchema);

module.exports = ImageModel;