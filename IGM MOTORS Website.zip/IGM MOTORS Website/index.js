const express = require("express");
const path = require("path");
var hbs = require("hbs");
const mongoose = require("mongoose");
const bodyParser = require('body-parser');
const session = require('express-session');
const flash = require('connect-flash');


const AuthRouter = require("./routes/auth");
const VehicleRouter = require("./routes/Vehicle");
const buyerDashboardRouter = require("./routes/BuyerDashboardRouter");

const app = express();
const port = 3000 || process.env.PORT;
const staticPath = path.join(__dirname, "static");
const partialPath = path.join(__dirname, "./views/partials");
const templatePath = path.join(__dirname, "./views");

const db_URL = 'mongodb://contactimtanan:cfd%402878@ac-t4vk7kn-shard-00-00.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-01.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-02.omvaq7k.mongodb.net:27017/?ssl=true&replicaSet=atlas-fojkho-shard-0&authSource=admin&retryWrites=true&w=majority';
// const db_URL = 'mongodb+srv://contactimtanan:cfd%402878@igmmotors.omvaq7k.mongodb.net/?retryWrites=true&w=majority';
// const db_URL = 'mongodb://127.0.0.1:27017/IGMMotors';
// Setting templete engine.
app.set("view engine", "hbs");

// Connecting DB(MongoDB)
const db = async () => {
  try {
    const conn = await mongoose.connect(db_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });

    console.log("MongoDB connected");
  } catch (err) {
    console.log("MongoDB Error : Failed to connect");
    console.log(err);
    process.exit(1);
  }
};

db();

// Set static folder path to use static files like JS,CSS,images
app.use("/static", express.static(staticPath));
// Parse URL-encoded data
app.use(express.urlencoded({ extended: false }));

// For parsing application/json
app.use(express.json());
app.use(session({
  secret: 'IGMMotors',
  saveUninitialized: true,
  resave: true
}));

app.use(flash());
 
// For parsing application/x-www-form-urlencoded
app.use(express.urlencoded({ extended: true }));

hbs.registerPartials(partialPath);

app.get("/", (req, res) => {
  res.render("home");
});

app.use('/Vehicles_Dashboard', VehicleRouter);
app.use('/Buyer-Dashboard', buyerDashboardRouter);

// Login a user
// const test = async (email, password) => {
//   const user = await User.findOne({ email: email });
//   const result = await user.comparePassword(password);
//   console.log(result);
// };

// Authentication(Login/Register) a user
app.use("/auth", AuthRouter);

app.get("*",(req,res)=>{
  res.status(404);
  res.render("404Page")
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`, app.settings.env);
});
