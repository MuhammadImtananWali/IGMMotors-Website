// const flash = require("connect-flash");
const passport = require("passport");
const express = require("express");
const bcrypt = require("bcrypt");

const app = express();
const saltRounds = 10;

const cookieParser = require("cookie-parser");
const session = require('express-session');

const User = require("../models/UserModel");

app.use(cookieParser());
// app.use(flash());

// For parsing application/json
app.use(express.json());


// Function to compare password.
const comparePassword = async function (password) {
  try {
    const result = await bcrypt.compare(password, this.password);
    return result;
  } catch (error) {
    console.log('Error while comparing password!');
  }
};

const login = async (req, res,next) => {
  const user = await User.findOne({ email: req.body.email });
  if (user) {
    const result = await comparePassword(req.body.password);
    console.log(result);
    if (result) {
      req.session.user = user;
      req.session.save();
      console.log("User logged in");
      res.redirect("/");
    } else {
      console.log("Password doesn't match.");
    }
  } else {
    console.log("Email not exist.");
    next();
  }
};

const logout = (req, res) => {
    req.session.destroy();
    console.log("User logged out!");
};

const register = async (req, res, next) => {
    try {
        const salt = await bcrypt.genSalt(saltRounds);
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        let user = new User({
            name: req.body.name,
            email: req.body.email,
            phone: parseInt(req.body.phone),
            password: hashedPassword
        });
        await user.save()
        alter('success', 'You have Registered')
        res.redirect("/");
        // passport.authenticate("local")(
        //     req, res, function () {
            
        // });
    } catch (error) {
        // res.json({
        //     // message: "Registered"
        //     message: "An error occurred!";
            
        // });
        res.render("home");
    }
};


module.exports = {
    login,
    register,
    logout
}











// const login = (req, res, next) => {
//     var username= req.body.username
//     var password = req.body.password
//     User.findOne({$or: [{email:username}, {phone:username}]})
//     .then(user =>{
//     if(user){
//     bcrypt.compare (password, user.password, function (err, result) { {
//     if (err)
//     res.json({
//     error: err
//     })
//     }
//     if(result) {
//     let
//     token
//     jwt.sign({name:
//     user.name},
//     'verySecretValue'
//     ,
//     {expiresIn:
//     '1h'})
//     res.json({
//     message
//     : 'Login Successful!',
//     token
//     =
//     })
//     }else{
//     res.json({
//     message:"Password does not matched!"
//     })
// }
//     })
// }
// else{
//     res.json({message:"No user Found!"})
// }
//     })
