const UserModel = require("../models/UserModel");
const passport = require("passport");
const jwt = require("jsonwebtoken");
const express = require("express");
const bcrypt = require("bcrypt");
const path = require("path");

const saltRounds = 10;
const app = express();

const register = async (req, res, next) => {
    try {
        const salt = await bcrypt.genSalt(saltRounds);
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        let user = new UserModel({
            name: req.body.name,
            email: req.body.email,
            phone: parseInt(req.body.phone),
            password: hashedPassword
        });
        await user.save()
        passport.authenticate("local")(
            req, res, function () {
            alter('success', 'You have Registered')
            res.render("Vehicles_Dashboard");
        });
    } catch (error) {
        res.json({
            message: "Registered"
            // message: "An error occurred!"
        });
    }
};


module.exports = {
    register
}











// const login = (req, res, next) => {
//     var username= req.body.username
//     var password = req.body.password
//     User.findOne({$or: [{email:username}, {phone:username}]})
//     .then(user =>{
//     if(user){
//     bcrypt.compare (password, user.password, function (err, result) { {
//     if (err)
//     res.json({
//     error: err
//     })
//     }
//     if(result) {
//     let
//     token
//     jwt.sign({name:
//     user.name},
//     'verySecretValue'
//     ,
//     {expiresIn:
//     '1h'})
//     res.json({
//     message
//     : 'Login Successful!',
//     token
//     =
//     })
//     }else{
//     res.json({
//     message:"Password does not matched!"
//     })
// }
//     })
// }
// else{
//     res.json({message:"No user Found!"})
// }
//     })
