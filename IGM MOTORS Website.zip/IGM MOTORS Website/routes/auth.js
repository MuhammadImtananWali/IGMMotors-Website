const express = require("express");
const path = require("path");
var hbs = require("hbs");
const router = express.Router();

const AuthController  = require("../controllers/AuthController")
const partialPath = path.join(__dirname, "./views/partials");

hbs.registerPartials(partialPath);

// router.get("/login", (req,res)=>{
//     res.render("authForm");
// });
router.post("/login", AuthController.login);
router.post("/logout", AuthController.logout);
router.post("/register", AuthController.register);

module.exports = router;