var express = require('express');
const mongoose = require('mongoose');
const path = require("path");
var router = express.Router();
const Vehicle = require('../models/VehicleModel');
const staticPath = path.join(__dirname, "../static");
let vehicleType;

// Set static folder path to use static files like JS,CSS,images
router.use("/static", express.static(staticPath));

router.get('/:type', async (req, res) => {
    // Veicle type is passed as a parameter
    if ( req.params.type === "car" || req.params.type === "bike" || req.params.type === "truck" || req.params.type === "boat") {
      try {
        vehicleType = req.params.type;
        const items = await Vehicle.find({ type: req.params.type });
        // res.json(items); 
        res.render("Vehicles_Dashboard", { models: items });
      } catch (err) {
        res.status(500).json({ error: "Error retrieving items from MongoDB" });
      }
    }
    else {
      res.status(404); 
      res.render("404Page");
    }
});

// GET Filtering vehicles
console.log("-----------",vehicleType);
router.get('/'+vehicleType+'/filter', async function (req, res) {
    console.log("---------",req.query);
    console.log("---------",req.params);
    // Sorting
    let filtered_models;

    const sortBy = req.query.sortBy;
    console.log(sortBy);

    if (sortBy == 'latest') {
        filtered_models = await Vehicle.find().sort({ year: -1 });
    }
    else if (sortBy == 'highprice') {
        filtered_models = await Vehicle.find().sort({ price: -1 });
    }
    else if (sortBy == 'lowprice') {
        filtered_models = await Vehicle.find().sort({ price: 1 });
    }
    else if (sortBy == 'highrange') {
        filtered_models = await Vehicle.find().sort({ range: -1 });
    }
    else if (sortBy == 'lowrange') {
        filtered_models = await Vehicle.find().sort({ range: 1 });
    }
    else if (sortBy == 'highperf') {
        filtered_models = await Vehicle.find().sort({ time60: 1 });
    }
    else if (sortBy == 'lowperf') {
        filtered_models = await Vehicle.find().sort({ time60: -1 });
    }


    // Price Filtering
    const priceBy = req.query.priceBy;
    console.log(priceBy);
    if (priceBy != undefined) {
        const priceLt = priceBy.slice(5) + '000';
        console.log(priceLt);
        filtered_models = await Vehicle.find({ price: { $lte: priceLt } }).sort({ price: -1 });
    }


    // Year Filtering
    var year = req.query.year;
    if (year != undefined) {
        year = year.slice(4);
        console.log(year);
        filtered_models = await Vehicle.find({ year: year });
    }

    var yearLt = req.query.yearLt;
    if (yearLt != undefined) {
        yearLt = yearLt.slice(4);
        console.log(yearLt);
        filtered_models = await Vehicle.find({ year: { $lte: yearLt } });
    }
    //console.log(filtered_models);
    res.render("Vehicles_Dashboard.hbs", { models: filtered_models });

});


module.exports = router;