const flash = require("connect-flash");
const express = require("express");
const path = require("path");
var hbs = require("hbs");
const crypto = require("crypto");
const mongoose = require("mongoose");
const passport = require("passport");
const session = require("express-session");
const cookieParser = require('cookie-parser');
const toastr = require('express-toastr');

const AuthRouter = require("./routes/auth");
const VehicleRouter = require("./routes/Vehicle");
const PasswordRouter = require("./routes/passwordRouter");
const buyerDashboardRouter = require("./routes/BuyerDashboardRouter");
const emailsRouter = require("./routes/mailsRouter");

const User = require("./models/UserModel");
const Image = require("./models/ImagesModel");
const Vehicle = require("./models/VehicleModel");
const Message = require("./models/MessageModel");

const app = express();
const port = 3000 || process.env.PORT;
// var CurrentUser = null;

const http = require("http");
const socketIo = require("socket.io");
const server = http.createServer(app);
const io = socketIo(server);

// Generate a random 32-byte (256-bit) secret key
const secretKey = crypto.randomBytes(32).toString("hex");
const staticPath = path.join(__dirname, "static");
const partialPath = path.join(__dirname, "./views/partials");
const templatePath = path.join(__dirname, "./views");

const db_URL =
  "mongodb://contactimtanan:cfd%402878@ac-t4vk7kn-shard-00-00.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-01.omvaq7k.mongodb.net:27017,ac-t4vk7kn-shard-00-02.omvaq7k.mongodb.net:27017/IGMMotors?ssl=true&replicaSet=atlas-fojkho-shard-0&authSource=admin&retryWrites=true&w=majority";

hbs.registerPartials(partialPath);
// Define the custom equality helper
hbs.registerHelper("if_eq", function (a, b, opts) {
  if (a === b) {
    return opts.fn(this);
  } else {
    return opts.inverse(this);
  }
});

// Setting templete engine.
app.set("views", templatePath);
app.set("view engine", "hbs");

// Connecting DB(MongoDB)
const db = async () => {
  try {
    const conn = await mongoose.connect(db_URL, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    console.log("MongoDB connected");
  } catch (error) {
    req.toastr.error(`${error.message}`,"ERROR");
    res.status(500);
    process.exit(1);
  }
};

db();

// Set static folder path to use static files like JS,CSS,images
app.use("/static", express.static(staticPath));
// Parse URL-encoded data
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser('secret'));
app.use(
  session({
    secret: secretKey,
    saveUninitialized: true,
    resave: true,
    cookie: { maxAge: 60 * 60 * 1000 * 1000 }, // 1 hour
  })
);

app.use(flash()); // use connect-flash for flash messages stored in session
app.use(toastr({
  closeButton: true,
  progressBar: true,
  positionClass: 'toast-bottom-right',
}));
app.use((req, res, next)=>{
  res.locals.toasts = req.toastr.render();
  next();
});

app.use((req, res, next) => {
  if (req.session.passport) {
    CurrentUser = req.session.passport.user;
  }
  next();
});
app.use(passport.initialize());
app.use(passport.session());
app.use("/password", PasswordRouter);
app.use("/Vehicles_Dashboard", VehicleRouter);
app.use("/Buyer-Dashboard", buyerDashboardRouter);
app.use("/emails", emailsRouter);
// Authentication(Login/Register) a user
app.use("/auth", AuthRouter);

const initializePassport = require("./controllers/passport-config");
initializePassport(
  passport,
  async (email) => await User.findOne({ email: email }),
  async (id) => {
    const user = await User.findOne({ _id: id });
    return user;
  }
);

// Find electric cars and their images
async function findElectricCarsAndImages() {
  try {
    const electricCars = await Vehicle.find({ type: "car", isElectric: true });

    if (electricCars.length > 0) {
      const electricCarIds = electricCars.map((car) => car._id);
      const electricCarImages = await Image.find({
        vehicle: { $in: electricCarIds },
      });
      return electricCarImages;
    } else {
      // If there are no electric cars, find vehicles with the most images
      const mostImagesVehicles = await Vehicle.aggregate([
        {
          $group: {
            _id: "$type",
            maxImages: { $max: { $size: "$images" } },
          },
        },
        {
          $lookup: {
            from: "vehicles",
            localField: "_id",
            foreignField: "type",
            as: "vehicles",
          },
        },
        {
          $unwind: "$vehicles",
        },
        {
          $match: {
            $expr: { $eq: [{ $size: "$vehicles.images" }, "$maxImages"] },
          },
        },
      ]);

      const mostImagesVehicleIds = mostImagesVehicles.map(
        (vehicle) => vehicle.vehicles._id
      );
      const mostImages = await Image.find({
        vehicle: { $in: mostImagesVehicleIds },
      });

      return mostImages;
    }
  } catch (error) {
    req.toastr.error(`${error.message}`,"ERROR");
    res.status(500);
  }
}

// async function getAllMessages(currentUser) {
//   // Step 1: Get Unread Messages
//   const unreadMessages = await Message.find({
//     receiver_id: currentUser,
//     isRead: false,
//   })
//     .populate("sender_id")
//     .exec();

//   // Create an object to store unique records with sender IDs as keys
//   const uniqueRecords = {};

//   // Loop through the unread messages and aggregate counts
//   for (const message of unreadMessages) {
//     const senderID = message.sender_id._id.toString(); // Convert ObjectId to string
//     if (!uniqueRecords[senderID]) {
//       // Initialize the unique record with the sender ID and count
//       uniqueRecords[senderID] = {
//         senderId: senderID,
//         senderName: message.sender_id.name,
//         receiverId: message.receiver_id.toString(),
//         messagesCount: 1,
//       };
//     } else {
//       // If the sender ID already exists, increment the count
//       uniqueRecords[senderID].messagesCount += 1;
//     }
//   }

//   // Now, uniqueRecords will contain unique records with sender IDs and their counts
//   return Object.values(uniqueRecords);
// }

async function getAllMessages(currentUser) {
  try {
    // Step 1: Get all messages for the current user
    const allMessages = await Message.find({
      $or: [
        { sender_id: currentUser },
        { receiver_id: currentUser },
      ],
    }).populate('sender_id receiver_id');

    console.log("count: ",allMessages.length);

    const uniqueRecords = {};

    allMessages.forEach((message) => {
      const otherUserId = (message.sender_id._id.equals(currentUser)) ? message.receiver_id._id : message.sender_id._id;
      const key = `${currentUser.toString()}_${otherUserId.toString()}`;
      console.log("message: ",message);
  
        if (!uniqueRecords[key]) {
          // Initialize the unique record with the sender and receiver IDs and count
          uniqueRecords[key] = {
            senderId: message.sender_id._id.toString(),
            senderName: message.sender_id.name,
            receiverId: message.receiver_id._id.toString(),
            messagesCount: 0,
          };
        } else {
          // If the key already exists, increment the count
          if(!message.isRead && message.receiver_id._id == currentUser)
          {
            uniqueRecords[key].messagesCount += 1;
          }
        }
    });
    // Filter records with isRead: false
    // const unreadRecords = Object.values(uniqueRecords).filter(record => record.messagesCount > 0);

    console.log("uniqueRecords: ",uniqueRecords);
    return uniqueRecords;
  } catch (error) {
    // Handle the error appropriately
    console.error(error);
    throw error;
  }
}


app.get("/", async (req, res) => {
  let uniqueRecordsArray = null;
  if (req.isAuthenticated()) {
    uniqueRecordsArray = await getAllMessages(req.session.passport.user);
    flag = true;
  } else {
    flag = false;
  }
  const finalImages = await findElectricCarsAndImages();

  const imageMap = [];
  finalImages.forEach((image) => {
    const base64Data = image.imageData.data.toString("base64");
    imageMap.push({
      contentType: image.imageData.contentType,
      data: base64Data,
    });
  });

  // Get the first five or fewer items from imageMap
  const numberOfImagesToShow = 5;
  const imagesToRender = imageMap.slice(0, numberOfImagesToShow);
  res.render("home", {
    loginCheck: flag,
    images: imagesToRender,
    Messages: uniqueRecordsArray,
  });
});

// Route handler
app.get("/profile", (req, res) => {
  console.log("Logged in user:", req.session.passport);
  if (req.isAuthenticated()) {
    // User is logged in
    console.log("Logged in user:", req.session.passport.user);
  } else {
    console.log("No user");
  }
});

app.get("/getMessages", async (req, res) => {
  try {
    var messages = new Message({
      sender_id: req.session.passport.user,
      receiver_id: req.query.receiverID,
      message: req.query.message,
    });
    await messages.save();
    return;
  } catch (error) {
    req.toastr.error(`${error.message}`,"ERROR");
    res.status(500);
  }
});

app.get("*", (req, res) => {
  res.status(404);
  res.render("404Page");
});

io.on("connection", (socket) => {
  console.log("User Connected.");

  socket.on("send", (receiverID, message) => {
    if (receiverID && message) {
      socket.broadcast.emit("loadNewChat", message, "left");
    }
  });
  socket.on("disconnect", () => {
    console.log("User Disconnect.");
  });

  // Load Existing chats.
  socket.on("existingChat", async (senderId, receiverID) => {
    if (senderId && receiverID) {
      var chats = await Message.find({
        $or: [
          {
            sender_id: senderId,
            receiver_id: receiverID,
          },
          {
            sender_id: receiverID,
            receiver_id: senderId,
          },
        ],
      });
      await Message.updateMany(
        { sender_id: receiverID, receiver_id: CurrentUser, isRead: false }, // Conditions for updating
        { $set: { isRead: true } } // Values to be updated
      );
      socket.emit("loadAllChats", chats, senderId, receiverID);
    }
  });
});

server.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

exports.getAllMessages = getAllMessages;
