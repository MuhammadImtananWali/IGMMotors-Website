const mongoose = require("mongoose");

const subscriptionSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true, // Ensure each email is unique
    trim: true, // Remove extra whitespace
  }
});

const Subscription = mongoose.model("Subscription", subscriptionSchema);

module.exports = Subscription;
