const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  buyer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  seller: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  vehicle: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true },
  transactionDate: { type: Date, default: Date.now },
  price: Number,
  status: String
});

const TransactionModel = mongoose.model('Transaction', transactionSchema);

module.exports = TransactionModel;