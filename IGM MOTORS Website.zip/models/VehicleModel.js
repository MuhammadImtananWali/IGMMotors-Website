const mongoose = require("mongoose");

const vehicleSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    lowercase: true,
    enum: ["car", "truck", "boat", "bike"],
  },
  make: { type: String, required: true },
  model: { type: String, required: true },
  year: { type: Number, required: true },
  price: { type: Number, required: true },
  color: { type: String, required: true },
  description: String,
  owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  isElectric: { type: Boolean },
  bodyType: { type: String, required: true }, // Add body type field
  location: { type: String, required: true }, // Add location field
  features: { type: [String], required: true }, // Add an array for features
  fuelType: {
    type: String,
    required: function () {
      // Check if the vehicle type is 'car' and the body type is not 'electric_car'
      return this.type == "car" && this.bodyType != "electric_car";
    },
  },
  // engineSize: { type: String, required: true }, // Add engine size field
  vehicleCondition: {
    type: String,
    required: true,
    enum: ["New", "Used"], // Enumerated values for car condition
  },
});

// Combination of Make, Model, and Year ensure that no two vehicles have the same combination of "make", "model", and "year.
vehicleSchema.index({ make: 1, model: 1, year: 1 }, { unique: true });
const VehicleModel = mongoose.model("Vehicle", vehicleSchema);

module.exports = VehicleModel;
