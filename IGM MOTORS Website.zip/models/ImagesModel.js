const mongoose = require('mongoose');

const imageSchema = new mongoose.Schema({
  vehicle: { type: mongoose.Schema.Types.ObjectId, ref: 'Vehicle', required: true },
  imageData: { data: Buffer, contentType: String }
});

const ImageModel = mongoose.model('Image', imageSchema);

module.exports = ImageModel;